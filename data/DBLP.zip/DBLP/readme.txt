###对于ACM dataset可以对所有node都采用标准的subgraph sampling method;所有node都有同样dim的feature

##link.data
#代表edge；ACM的edge可视作有向边，paper-author和author-paper也是不同的type
第一列第二列分别代表两个点
第三列代表edge type
edge的方向取决于edge type

##label.data
#代表node type 0：paper的label（属于哪类）
第一列代表node id
第二列代表node type（都为0）
第三列代表node class

##node.data
#代表所有type的node
#########################
需要考虑node feature的预处理
#不同type的feature不同：
1.0,1是one-hot feature；2是连续feature；3是text没有feature；（虽然info中记录0也没有feature，但实际上node中有其feature)
#########################
开头数字代表node id
id后有一段description（paper是abstract；author是name；）
description后是node type
node type后是feature

##info.data
代表schema:
所有edge都是与node type 1相连接的；必然以node type 1为起点或者终点；
node classification也是只对node type 0进行；
##因此：
1.对于node type 1做subgraph sampling时候可以按照设想的标准sampling方法分别获得same type sampling subgraphs & multiple type sampling subgraph;
2.对于node type 0,2,3做subgraph sampling时候，因为他们都只和node type 0相连，取1 hop subgraph时，只能获得一种subgraph即都是node type 1做邻居的subgraph；只有hop num大于1时候，才可能获得其他种类的subgraphs；但由于其他类的subgraph都不是通过直接相连获得的，关联性会相对较弱


